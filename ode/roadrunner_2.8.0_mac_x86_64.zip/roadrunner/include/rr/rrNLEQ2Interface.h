#ifndef rrNLEQInterfaceH
#define rrNLEQInterfaceH
#include <vector>
#include "rrExporter.h"
#include "rrExecutableModel.h"
#include "Dictionary.h"

using std::vector;

namespace rr
{

/**
 * @cond PRIVATE
 */
class RR_DECLSPEC NLEQ2Interface : public Dictionary
{

public:
    /**
     * Creates a new Instance of NLEQ for the given Model
     */
    NLEQ2Interface(ExecutableModel *_model = NULL);

    ~NLEQ2Interface();

    /**
     * Thea actual solver routine making the call to NLEQ2
     *
     * @return sums of squares
     */
    double solve();


    /**
     * Implement Dictionary Interface
     */
public:

    /**
     * set an arbitrary key
     */
    virtual void setItem(const std::string& key, const rr::Setting& value);

    /**
     * get a value. Variants are POD.
     */
    virtual Setting getItem(const std::string& key) const;

    /**
     * is there a key matching this name.
     */
    virtual bool hasKey(const std::string& key) const;

    /**
     * remove a value
     */
    virtual size_t deleteItem(const std::string& key);

    /**
     * list of keys in this object.
     */
    virtual std::vector<std::string> getKeys() const;

    /**
     * list of keys that this integrator supports.
     */
    static const Dictionary* getSteadyStateOptions();


public:
    int nOpts;
    long *IWK;
    long LIWK;
    long LRWK;
    double *RWK;
    double *XScal;
    long ierr;
    long *iopt;
    ExecutableModel *model; // Model generated from the SBML. Static so we can access it from standalone function
    long n;
    void setup();

    bool isAvailable();

    bool allowPreSim;
    double preSimTolerance;
    int preSimMaximumSteps;
    double preSimTime;
    bool allowApprox;
    double approxTolerance;
    int approxMaximumSteps;
    double approxTime;
    double relativeTolerance;
    int maxIterations;
    double minDamping;
    int broyden;
    int linearity;


    /// <summary>
    /// Sets the Scaling Factors
    /// </summary>
    /// <param name="sx">Array of Scaling factors</param>
    void                            setScalingFactors(const std::vector<double>& sx);

    /// <summary>
    /// Returns the Number of Newton Iterations
    /// </summary>
    /// <returns>the Number of Newton Iterations</returns>
    int                             getNumberOfNewtonIterations();

    /// <summary>
    /// Returns the Number of Corrector steps
    /// </summary>
    /// <returns>Returns the Number of Corrector steps</returns>
    int                             getNumberOfCorrectorSteps();

    /// <summary>
    /// Returns the Number of Model Evaluations
    /// </summary>
    /// <returns>the Number of Model Evaluations</returns>
    int                             getNumberOfModelEvaluations();

    /// <summary>
    /// Returns the Number Of Jacobian Evaluations
    /// </summary>
    /// <returns>the Number Of Jacobian Evaluations</returns>
    int                             getNumberOfJacobianEvaluations();

    /// <summary>
    /// Returns the Number of Model Evaluations For Jacobian
    /// </summary>
    /// <returns>the Number of Model Evaluations For Jacobian</returns>
    int                             getNumberOfModelEvaluationsForJacobian();


    double                          computeSumsOfSquares();

    friend class NLEQ2Solver;

};
/** @endcond PRIVATE */
}

#endif
